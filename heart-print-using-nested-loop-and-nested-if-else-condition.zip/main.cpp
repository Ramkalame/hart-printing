#include <iostream>

using namespace std;

int main()
{
    
    for(int i = 0; i<7; i++)
    {
        for(int j = 0; j<=6; j++)
        {
            if(i ==0)
            {
                if(i== 0 && j == 1 || i== 0 && j == 2 || i== 0 && j == 4 || i== 0 && j==5)
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
           
            if(i == 1)
            {
                if((i == 1 && j == 0) || (i == 1 && j ==3) || (i == 1 && j == 6))
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
            
            if(i == 2)
            {
                if(i == 2 && j == 6  || i == 2 && j ==0 )
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
            
            if(i == 3)
            {
                if(i == 3 && j ==1 || i == 3 && j ==5  )
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
            
            if(i == 4)
            {
                if(i == 4 && j ==2 || i == 4 && j ==4)
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
            
            if(i == 5 )
            {
                if(i == 5 && j ==3)
                {
                    cout<<"* ";
                }
                else
                {
                    cout<<"  ";
                }
            }
            
            
            
        }
        cout<<endl;
    }
    

    return 0;
}

// int p =0;
    // string name = "Ramswarup kalame";
    // for(int i = 0; i < sizeof(name); i++)
    // {
        
    //     for(int j = 0; j<i; j++)
    //     {
    //         cout<<name[p];
    //         p++;
    //     }
    //     cout<<endl;
        
    // }

